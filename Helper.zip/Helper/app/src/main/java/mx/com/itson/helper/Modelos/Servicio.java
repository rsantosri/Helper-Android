package mx.com.itson.helper.Modelos;

import java.sql.Date;

public class Servicio {

    int id;
    int idUsuarioCliente;
    int idProveedor;
    Date fechaOrden;
    Date fechaServicio;
    String descripcionNecesidades;
    boolean aceptado;
    boolean completado;

    public Servicio() {
    }

    public Servicio(int id, int idUsuarioCliente, int idProveedor, Date fechaOrden, Date fechaServicio, String descripcionNecesidades, boolean aceptado, boolean completado) {
        this.id = id;
        this.idUsuarioCliente = idUsuarioCliente;
        this.idProveedor = idProveedor;
        this.fechaOrden = fechaOrden;
        this.fechaServicio = fechaServicio;
        this.descripcionNecesidades = descripcionNecesidades;
        this.aceptado = aceptado;
        this.completado = completado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuarioCliente() {
        return idUsuarioCliente;
    }

    public void setIdUsuarioCliente(int idUsuarioCliente) {
        this.idUsuarioCliente = idUsuarioCliente;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public Date getFechaOrden() {
        return fechaOrden;
    }

    public void setFechaOrden(Date fechaOrden) {
        this.fechaOrden = fechaOrden;
    }

    public Date getFechaServicio() {
        return fechaServicio;
    }

    public void setFechaServicio(Date fechaServicio) {
        this.fechaServicio = fechaServicio;
    }

    public String getDescripcionNecesidades() {
        return descripcionNecesidades;
    }

    public void setDescripcionNecesidades(String descripcionNecesidades) {
        this.descripcionNecesidades = descripcionNecesidades;
    }

    public boolean isAceptado() {
        return aceptado;
    }

    public void setAceptado(boolean aceptado) {
        this.aceptado = aceptado;
    }

    public boolean isCompletado() {
        return completado;
    }

    public void setCompletado(boolean completado) {
        this.completado = completado;
    }
}
