package mx.com.itson.helper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.RadialPickerLayout;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import mx.com.itson.helper.Modelos.Oferta;
import mx.com.itson.helper.Modelos.Proveedor;
import mx.com.itson.helper.Modelos.RecyclerAdapterOferta;

public class Solicitud_Fecha extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {


    FirebaseDatabase database;
    DatabaseReference myRef ;
    Proveedor proveedor;

    TextView nombre, descripcionProveedor, fecha, hora;
    ImageView imagenProveedor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solicitud__fecha);
        final String idProveedor = getIntent().getStringExtra("id");

        nombre = findViewById(R.id.nombreCrearSolicitud);
        descripcionProveedor = findViewById(R.id.descripcionCrearSolicitud);
        imagenProveedor = findViewById(R.id.imgCrearSolicitud);
        fecha = findViewById(R.id.lblFecha);
        hora = findViewById(R.id.lblHora);




        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("proveedores");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.


                for(DataSnapshot dataSnapshot1 :dataSnapshot.getChildren()){

                    Proveedor value = dataSnapshot1.getValue(Proveedor.class);
                    if (value.getIdUsuarioProveedor() == Integer.parseInt(idProveedor)){
                        proveedor = new Proveedor();
                        int id = value.getIdUsuarioProveedor();
                        String descripcion = value.getDescripcion();
                        String imagen = value.getImagen();
                        double costo = value.getCostoPromedio();

                        proveedor.setIdUsuarioProveedor(id);
                        proveedor.setDescripcion(descripcion);
                        proveedor.setImagen(imagen);
                        proveedor.setCostoPromedio(costo);
                        proveedor.setIdCategoria(value.getIdCategoria());
                        proveedor.setOferta(value.getOferta());
                        proveedor.setNombre(value.getNombre());

                        nombre.setText(proveedor.getNombre());
                        descripcionProveedor.setText(proveedor.getDescripcion());
                        new DownLoadImageTask(imagenProveedor).execute(proveedor.getImagen());






                    }


                }




            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("Hello", "Failed to read value.", error.toException());
            }
        });

    }



    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        String date = "You picked the following date: "+dayOfMonth+"/"+(monthOfYear+1)+"/"+year;
        fecha.setText(date);
    }

    @Override
    public void onTimeSet(TimePickerDialog view, int hourOfDay, int minute, int second) {
        String time = "You picked the following time: "+hourOfDay+"h"+minute+"m"+second;

        hora.setText(time);
    }

    private class DownLoadImageTask extends AsyncTask<String,Void,Bitmap> {
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView){
            this.imageView = imageView;
        }

        protected Bitmap doInBackground(String...urls){
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try{
                InputStream is = new URL(urlOfImage).openStream();
                logo = BitmapFactory.decodeStream(is);
            }catch(Exception e){
                e.printStackTrace();
            }
            return logo;
        }


        protected void onPostExecute(Bitmap result){
            imageView.setImageBitmap(result);
        }
    }

    public void abrirDate(View view){
        Calendar now = Calendar.getInstance();
        DatePickerDialog dpd = DatePickerDialog.newInstance(
                Solicitud_Fecha.this,
                now.get(Calendar.YEAR), // Initial year selection
                now.get(Calendar.MONTH), // Initial month selection
                now.get(Calendar.DAY_OF_MONTH) // Inital day selection
        );

        dpd.setVersion(DatePickerDialog.Version.VERSION_2);
        dpd.setAccentColor(getResources().getColor(R.color.colorPrimary));
        dpd.show(getSupportFragmentManager(), "Datepickerdialog");
    }
    public void abrirTime(View view){
        Calendar now = Calendar.getInstance();
        TimePickerDialog dpd = TimePickerDialog.newInstance(Solicitud_Fecha.this,
        now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), now.get(Calendar.SECOND), false);

        dpd.setVersion(TimePickerDialog.Version.VERSION_2);
        dpd.setAccentColor(getResources().getColor(R.color.colorPrimary));
        dpd.show(getSupportFragmentManager(), "Datepickerdialog");
    }
}
